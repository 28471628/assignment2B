import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        
       /* System.out.println("-PSN-");
       pn();
        System.out.println("-PSP-");
        prp();*/
        System.out.println("-RR-");
        rr();
    }
    
   
    
    /*public static void pn()
    {
        CPUScheduler pn = new PriorityNonPreemptive();
        pn.add(new Row("P1", 8, 1));
        pn.add(new Row("P2", 5, 1));
        pn.add(new Row("P3", 2, 7));
        pn.add(new Row("P4", 4, 3));
        pn.add(new Row("P5", 2, 8));
        pn.add(new Row("P6", 4, 2));
        pn.add(new Row("P7", 3, 5));
        pn.process();
        display(pn);
    }
    
    public static void prp()
    {
        CPUScheduler prp = new PriorityPreemptive();
        prp.add(new Row("P1", 8, 1));
        prp.add(new Row("P2", 5, 1));
        prp.add(new Row("P3", 2, 7));
        prp.add(new Row("P4", 4, 3));
        prp.add(new Row("P5", 2, 8));
        prp.add(new Row("P6", 4, 2));
        prp.add(new Row("P7", 3, 5));
        prp.process();
        display(prp);
    }*/ //parts covered by other members
    
    public static void rr()
    {
        CPUScheduler rr = new RoundRobin();
        rr.setTimeQuantum(2);
        rr.add(new Row("P1", 0, 4));
        rr.add(new Row("P2", 1, 5));
        rr.add(new Row("P3", 2, 6));
        rr.add(new Row("P4", 4, 1));
        rr.add(new Row("P5", 6, 3));
        rr.add(new Row("P6", 7, 2));
        rr.process();
        display(rr);
    }
    
    public static void display(CPUScheduler object)
    {
        System.out.println("Process\tAT\tBT\tWT\tTAT");

        for (Row row : object.getRows())
        {
            System.out.println(row.getProcessName() + "\t" + row.getArrivalTime() + "\t" + row.getBurstTime() + "\t" + row.getWaitingTime() + "\t" + row.getTurnaroundTime());
        }
        
        System.out.println();
        
        for (int i = 0; i < object.getTimeline().size(); i++)
        {
            List<Event> timeline = object.getTimeline();
            System.out.print(timeline.get(i).getStartTime() + "(" + timeline.get(i).getProcessName() + ")");
            
            if (i == object.getTimeline().size() - 1)
            {
                System.out.print(timeline.get(i).getFinishTime());
            }
        }
        
        System.out.println("\n\nAverage WT: " + object.getAverageWaitingTime() + "\nAverage TAT: " + object.getAverageTurnAroundTime());
    }
}
